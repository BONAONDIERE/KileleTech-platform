<?php
$pageTitle = 'About Us';
include 'includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <div class="page-hero__breadcrumb"><a href="index.php">Home</a> / About Us</div>
        <h1 class="page-hero__title">About Kilele Tech</h1>
        <p class="page-hero__subtitle">
            A Nairobi-based technology consultancy delivering end-to-end ICT solutions to businesses, government agencies, and non-profits.
        </p>
    </div>
</section>

<section class="content-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <span class="why-choose-us__eyebrow">Who We Are</span>
                <h2 class="why-choose-us__heading" style="text-align:left;">Your trusted ICT partner</h2>
                <p style="color: var(--kilele-text-light); line-height: 1.8; margin-bottom: 16px;">
                    Kilele Tech is a technology consultancy firm based in Nairobi, Kenya. We provide end-to-end ICT
                    solutions to businesses, government agencies, and non-profits. Our mission is to help
                    organizations leverage technology to drive growth, improve security, and streamline operations.
                </p>
                <p style="color: var(--kilele-text-light); line-height: 1.8;">
                    Founded in August 2025, we've built a reputation for delivering reliable, innovative, and secure
                    technology solutions across multiple sectors — from software development to 24/7 security monitoring.
                </p>
            </div>
            <div class="col-lg-6">
                <div class="stat-row">
                    <div class="stat-row__item">
                        <strong>2025</strong>
                        <span>Year Founded</span>
                    </div>
                    <div class="stat-row__item">
                        <strong>8</strong>
                        <span>Service Areas</span>
                    </div>
                    <div class="stat-row__item">
                        <strong>100+</strong>
                        <span>Projects Delivered</span>
                    </div>
                    <div class="stat-row__item">
                        <strong>100%</strong>
                        <span>Client Satisfaction</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="content-section content-section--alt">
    <div class="container">
        <div class="text-center mb-5">
            <span class="why-choose-us__eyebrow">Our Value Proposition</span>
            <h2 class="why-choose-us__heading">What guides us every day</h2>
        </div>
        <div class="value-grid" style="grid-template-columns: repeat(3, 1fr);">
            <div class="value-card">
                <div class="value-card__icon"><i class="fas fa-bolt"></i></div>
                <h4>Technical Excellence</h4>
                <p>Our team stays ahead of the curve with the latest technologies and industry best practices.</p>
            </div>
            <div class="value-card">
                <div class="value-card__icon"><i class="fas fa-shield-halved"></i></div>
                <h4>Security First</h4>
                <p>We build security into every solution — from development to deployment.</p>
            </div>
            <div class="value-card">
                <div class="value-card__icon"><i class="fas fa-people-arrows"></i></div>
                <h4>Client-Centric Approach</h4>
                <p>We listen to your needs, understand your business, and deliver solutions that drive real results.</p>
            </div>
        </div>
    </div>
</section>

<section class="content-section text-center">
    <div class="container">
        <h2 class="why-choose-us__heading">"End-to-end technology solutions"</h2>
        <p class="why-choose-us__subcopy" style="margin-left:auto; margin-right:auto;">
            From software development to security monitoring — let's talk about what your organization needs.
        </p>
        <a href="quote.php" class="btn-hero-primary">Get a Free Consultation →</a>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
