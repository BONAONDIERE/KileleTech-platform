</main>

<!-- ============================================================
FOOTER
============================================================ -->
<footer class="kilele-footer">
    <div class="container">
        <div class="kilele-footer__grid">
            <div>
                <div class="kilele-footer__logo">
                    <span class="kilele-wordmark__text kilele-wordmark__text--footer">
                        <span class="wm-k">K</span><span class="wm-i">i</span><span class="wm-l1">l</span><span class="wm-e1">e</span><span class="wm-l2">l</span><span class="wm-e2">e</span>
                    </span>
                </div>
                <p class="kilele-footer__brand-text">
                    End-to-end technology solutions — from software development to security monitoring. We combine
                    technical expertise with business insight to deliver innovative, reliable, and secure ICT solutions.
                </p>
                <div class="kilele-footer__social">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                </div>
            </div>

            <div>
                <h5 class="kilele-footer__title">Quick Links</h5>
                <ul class="kilele-footer__links">
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="projects.php">Projects</a></li>
                    <li><a href="blogs.php">Blogs</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </div>

            <div>
                <h5 class="kilele-footer__title">Get in Touch</h5>
                <ul class="kilele-footer__contact">
                    <li><i class="fas fa-location-dot"></i> University of Nairobi, Main Campus</li>
                    <li><i class="fas fa-phone"></i> +254 757 111 227</li>
                    <li><i class="fas fa-envelope"></i> kileletechofficial@gmail.com</li>
                </ul>
            </div>

            <div>
                <h5 class="kilele-footer__title">Newsletter</h5>
                <p class="kilele-footer__newsletter-text">
                    Get ICT tips, security alerts and project updates from the Kilele Tech team.
                </p>
                
                <!-- Updated Form (No action, handled by AJAX) -->
                <form id="newsletterForm">
                    <div class="input-group">
                        <input type="email" name="email" id="newsletterEmail" class="form-control" placeholder="Your email" required style="border-radius: 50px 0 0 50px;">
                        <button class="btn btn-kilele-primary" type="submit" id="newsletterBtn" style="border-radius: 0 50px 50px 0;">Subscribe</button>
                    </div>
                    <div id="newsletterMsg" class="mt-2" style="font-size: 12px;"></div>
                </form>
            </div>
        </div>

        <div class="kilele-footer__bottom text-center">
            <small>&copy; <?php echo date('Y'); ?> Kilele Tech. All Rights Reserved. Your trusted ICT partner since 2025.</small>
        </div>
    </div>
</footer>

<!-- AJAX SCRIPT FOR NEWSLETTER -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('newsletterForm');
        const msg = document.getElementById('newsletterMsg');
        const btn = document.getElementById('newsletterBtn');

        form.addEventListener('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(form);
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>';

            // Fetch your existing process_subscribe.php in the root folder
            fetch('process_subscribe.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                msg.style.display = 'block';
                msg.style.padding = '5px 10px';
                msg.style.borderRadius = '5px';
                if (data.success) {
                    msg.style.background = '#d4edda'; 
                    msg.style.color = '#155724';
                    msg.textContent = data.message;
                    form.reset();
                } else {
                    msg.style.background = '#f8d7da'; 
                    msg.style.color = '#721c24';
                    msg.textContent = data.message;
                }
            })
            .catch(() => {
                msg.style.display = 'block';
                msg.style.padding = '5px 10px';
                msg.style.background = '#f8d7da'; 
                msg.style.color = '#721c24';
                msg.textContent = 'Could not reach the server. Please try again later.';
            })
            .finally(() => {
                btn.disabled = false;
                btn.innerHTML = 'Subscribe';
            });
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>