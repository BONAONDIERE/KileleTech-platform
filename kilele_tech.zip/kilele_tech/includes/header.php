<?php
if (!isset($pageTitle)) {
    $pageTitle = 'Kilele Tech';
}
$currentPage = basename($_SERVER['PHP_SELF']);
function navActive($file, $current) {
    return $file === $current ? ' active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?> - Kilele Tech</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/layout.css">
</head>
<body>

<!-- ============================================================
TOP BAR
============================================================ -->
<div class="top-bar-wrapper">
    <div class="top-bar-spacer"></div>
    <div class="top-bar-inner">
        <div class="top-contact">
            <span><i class="fas fa-envelope"></i> kileletechofficial@gmail.com</span>
            <span><i class="fas fa-map-marker-alt"></i> University of Nairobi, Main Campus</span>
        </div>
        <div class="top-right">
            <div class="top-links">
                <a href="about.php">About</a>
                <span class="sep">|</span>
                <a href="hub.php">FAQ</a>
                <span class="sep">|</span>
                <a href="contact.php">Contact</a>
            </div>
            <div class="top-social-icons">
                <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================
MAIN NAVIGATION
============================================================ -->
<nav class="navbar navbar-expand-lg kilele-navbar sticky-top">
    <div class="container kilele-nav-container">
        <a class="navbar-brand kilele-wordmark" href="index.php">
            <span class="kilele-wordmark__text">
                <span class="wm-k">K</span><span class="wm-i">i</span><span class="wm-l1">l</span><span class="wm-e1">e</span><span class="wm-l2">l</span><span class="wm-e2">e</span><span style="color: var(--kilele-primary); font-weight: 700;">Tech</span>
            </span>
            <span class="kilele-logo-tagline">Your Trusted ICT Partner</span>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav mx-auto align-items-lg-center">
                <li class="nav-item"><a class="nav-link<?php echo navActive('index.php', $currentPage); ?>" href="index.php">Home</a></li>

                <!-- About Us Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="aboutDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        About Us
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="aboutDropdown">
                        <li><a class="dropdown-item" href="about.php">About Us</a></li>
                        <li><a class="dropdown-item" href="team.php">Our Team</a></li>
                        <li><a class="dropdown-item" href="careers.php">Careers</a></li>
                    </ul>
                </li>

                <!-- Kilele Hub Dropdown (with Blogs inside) -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="hubDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Kilele Hub
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="hubDropdown">
                        <li><a class="dropdown-item" href="hub.php">Kilele Hub</a></li>
                        <li><a class="dropdown-item" href="blogs.php">Blogs</a></li>
                    </ul>
                </li>

                <!-- Services Dropdown (with Projects inside) -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="servicesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Services
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="servicesDropdown">
                        <li><a class="dropdown-item" href="services.php">All Services</a></li>
                        <li><a class="dropdown-item" href="projects.php">Projects</a></li>
                    </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="downloads.php">Downloads</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                <li class="nav-item"><a class="nav-link" href="kilele1.php">Kilele@1</a></li>
                <li class="nav-item"><a class="nav-link join-link" href="quote.php">Get a Quote</a></li>
                <li class="nav-item">
                    <button class="search-button ms-3" type="button" aria-label="Search"><i class="fas fa-search"></i></button>
                </li>
            </ul>
        </div>

        <div class="iconnect-row">
            <a class="iconnect-nav-link" href="quote.php">Free Consultation</a>
        </div>
    </div>
</nav>

<!-- ============================================================
ANNOUNCEMENT BAR
============================================================ -->
<div class="announcement-bar">
    <div class="announce-dot"></div>
    <div class="announce-viewport">
        <div class="announce-track" id="announceTrack">
            <div class="announce-item">
                <span class="announce-pill announce-pill--teal"><i class="fas fa-shield-halved"></i> Security</span>
                <span class="announce-copy">Free network security audit with every firewall consultation.</span>
                <a href="services.php" class="announce-cta">View Services <i class="fas fa-arrow-right"></i></a>
            </div>
            <span class="announce-sep">|</span>
            <div class="announce-item">
                <span class="announce-pill announce-pill--yellow"><i class="fas fa-tag"></i> Web</span>
                <span class="announce-copy">Website packages now starting from KES 30,000.</span>
                <a href="quote.php" class="announce-cta">Get a Quote <i class="fas fa-arrow-right"></i></a>
            </div>
            <span class="announce-sep">|</span>
            <div class="announce-item">
                <span class="announce-pill announce-pill--teal"><i class="fas fa-shield-halved"></i> Security</span>
                <span class="announce-copy">Free network security audit with every firewall consultation.</span>
                <a href="services.php" class="announce-cta">View Services <i class="fas fa-arrow-right"></i></a>
            </div>
            <span class="announce-sep">|</span>
            <div class="announce-item">
                <span class="announce-pill announce-pill--yellow"><i class="fas fa-tag"></i> Web</span>
                <span class="announce-copy">Website packages now starting from KES 30,000.</span>
                <a href="quote.php" class="announce-cta">Get a Quote <i class="fas fa-arrow-right"></i></a>
            </div>
            <span class="announce-sep">|</span>
        </div>
    </div>
    <a href="contact.php" class="announce-member-pill"><i class="fas fa-headset"></i> Client Support</a>
</div>

<!-- ============================================================
FLOATING SIDE PANEL
============================================================ -->
<div class="floating-side-panel">
    <a href="index.php" class="side-panel-item" data-hover-color="teal">
        <span class="side-panel-icon"><i class="fas fa-home"></i></span>
        <span class="side-panel-label">Home</span>
        <span class="side-panel-dot"></span>
    </a>
    <a href="quote.php" class="side-panel-item" data-hover-color="teal">
        <span class="side-panel-icon"><i class="fas fa-file-invoice"></i></span>
        <span class="side-panel-label">Get Quote</span>
        <span class="side-panel-dot"></span>
    </a>
    <a href="contact.php" class="side-panel-item" data-hover-color="yellow">
        <span class="side-panel-icon"><i class="fas fa-comment"></i></span>
        <span class="side-panel-label">Feedback</span>
        <span class="side-panel-dot"></span>
    </a>
    <a href="contact.php#map" class="side-panel-item" data-hover-color="coral">
        <span class="side-panel-icon"><i class="fas fa-map-marker-alt"></i></span>
        <span class="side-panel-label">Location</span>
        <span class="side-panel-dot"></span>
    </a>
</div>

<!-- ============================================================
MAIN CONTENT STARTS
============================================================ -->
<main>