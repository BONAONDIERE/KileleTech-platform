<?php
$pageTitle = 'Kilele Tech – Your Trusted ICT Partner';
include 'includes/header.php';
?>

<!-- ============================================================
HERO SECTION — two-panel split, same style, tech content
============================================================ -->
<section class="hero-carousel-section">
    <div class="hero-split">

        <div class="hero-panel hero-panel--left">

            <div class="hero-carousel-track" id="heroTrack">

                <!-- Slide 0 -->
                <div class="hero-slide active" data-index="0">
                    <div class="hero-slide__media hero-slide__media--tint1"></div>
                    <div class="hero-bubble">
                        <h3>End-to-end ICT solutions</h3>
                        <p>From software development to security monitoring — we combine technical expertise with business insight to deliver innovative, reliable and secure technology solutions.</p>
                        <ul class="hero-bubble__steps">
                            <li><span>1</span> Tell us about your business and current systems.</li>
                            <li><span>2</span> We assess and recommend the right ICT solution.</li>
                            <li><span>3</span> Our team designs, builds and deploys it.</li>
                            <li><span>4</span> You get ongoing support and monitoring.</li>
                        </ul>
                        <a href="services.php" class="btn-hero-primary mt-2">Explore Services →</a>
                    </div>
                </div>

                <!-- Slide 1 -->
                <div class="hero-slide" data-index="1">
                    <div class="hero-slide__media hero-slide__media--tint2"></div>
                    <div class="hero-bubble">
                        <h3 style="color: var(--kilele-yellow);">CCTV & Security Systems</h3>
                        <p style="font-style: italic;">"Security built into every solution — from development to deployment."</p>
                        <p>IP and analog CCTV, access control, biometrics and intrusion detection, with remote monitoring.</p>
                        <p style="color: var(--kilele-yellow); font-weight: 600;">Free consultation & system design.</p>
                        <a href="quote.php" class="btn-hero-primary mt-2">Request a Quote →</a>
                    </div>
                </div>

                <!-- Slide 2 -->
                <div class="hero-slide" data-index="2">
                    <div class="hero-slide__media hero-slide__media--tint3"></div>
                    <div class="hero-bubble">
                        <h3>Pick the right service package</h3>
                        <p>We tailor our support to how your business runs — explore <strong style="color: var(--kilele-yellow);">Starter, Business and Enterprise</strong> packages to find the fit.</p>
                        <div class="hero-tier-row">
                            <div class="hero-tier-chip"><div>🌱</div><div>Starter</div><small>Small Business</small></div>
                            <div class="hero-tier-chip"><div>💼</div><div>Business</div><small>Growing Teams</small></div>
                            <div class="hero-tier-chip"><div>🏢</div><div>Enterprise</div><small>Full ICT Partner</small></div>
                        </div>
                        <a href="quote.php" class="btn-hero-primary mt-2">Compare Packages →</a>
                    </div>
                </div>

            </div>

            <button class="hero-arrow hero-arrow--prev" id="heroPrev" aria-label="Previous slide"><i class="fas fa-chevron-left"></i></button>
            <button class="hero-arrow hero-arrow--next" id="heroNext" aria-label="Next slide"><i class="fas fa-chevron-right"></i></button>

            <div class="hero-dots">
                <span class="hero-dot active" data-index="0"></span>
                <span class="hero-dot" data-index="1"></span>
                <span class="hero-dot" data-index="2"></span>
            </div>

            <div class="hero-limit-badge">
                <small>SINCE</small>
                <strong>2025</strong>
            </div>

            <div class="hero-joinus-overlay">
                <div class="hero-joinus-overlay__title">Talk to Kilele Tech</div>
                <div class="hero-joinus-overlay__subtitle">Call:</div>
                <ul>
                    <li><span>Sales:</span> +254 757 111 222</li>
                    <li><span>Support:</span> +254 757 111 222</li>
                </ul>
            </div>
        </div>

        <div class="hero-panel hero-panel--right">
            <div class="hero-video-wrapper">
            <iframe 
    src="https://www.youtube.com/embed/pRQGR91AQdU?autoplay=1&mute=1&loop=1&playlist=pRQGR91AQdU&controls=1&modestbranding=1&rel=0&showinfo=0"
    allow="autoplay; encrypted-media"
    allowfullscreen
    title="KileleTech - Financial Freedom Starts Early">
</iframe>

                <span class="hero-now-playing"><i class="fas fa-play-circle me-1"></i> Now Playing</span>

                <div class="hero-balance-overlay">
                    <div class="hero-balance-overlay__label">Client Satisfaction</div>
                    <div class="hero-balance-overlay__amount">100%</div>
                </div>
            </div>
            <div class="hero-more-videos">
                <a href="#"><i class="fas fa-arrow-right me-1"></i> More on our channel</a>
            </div>
        </div>

    </div>
</section>

<!-- ============================================================
GENERAL STATS STRIP (repurposed from the balance/store section)
============================================================ -->
<section class="general-store-section">
    <div class="container">
        <div class="balance-card">
            <div>
                <div class="balance-label">PROJECTS DELIVERED</div>
                <div class="balance-amount">100+</div>
            </div>
            <div>
                <div class="store-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 12px; color: #888;">Need help fast?</div>
                    <a href="contact.php" style="color: var(--kilele-primary); font-size: 13px; font-weight: 600;">Contact Support →</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================
WHAT WE OFFER — 4 featured services, linking to full list
============================================================ -->
<section class="products-grid-section" style="padding: 60px 0 40px; background: #ffffff;">
    <div class="container">
        <div class="text-center mb-4">
            <span class="products-eyebrow" style="display: inline-block; font-size: 13px; font-weight: 700; color: var(--kilele-primary); text-transform: uppercase; letter-spacing: 2px; margin-bottom: 8px;">WHAT WE DO</span>
            <h2 class="products-title" style="font-size: 2.4rem; font-weight: 700; color: var(--kilele-navy);">What we offer — our ICT services</h2>
        </div>

        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="product-offer-card" style="background: #f8fafb; border-radius: 16px; padding: 30px 20px 25px; text-align: center; height: 100%;">
                    <div class="product-offer-icon" style="font-size: 2.8rem; color: var(--kilele-primary); margin-bottom: 16px;"><i class="fas fa-code"></i></div>
                    <h3 class="product-offer-title" style="font-size: 1.1rem; font-weight: 700; color: var(--kilele-navy); margin-bottom: 12px;">Software Development</h3>
                    <a href="services.php" class="product-offer-link" style="font-size: 0.85rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">READ MORE →</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="product-offer-card" style="background: #f8fafb; border-radius: 16px; padding: 30px 20px 25px; text-align: center; height: 100%;">
                    <div class="product-offer-icon" style="font-size: 2.8rem; color: var(--kilele-primary); margin-bottom: 16px;"><i class="fas fa-globe"></i></div>
                    <h3 class="product-offer-title" style="font-size: 1.1rem; font-weight: 700; color: var(--kilele-navy); margin-bottom: 12px;">Web Development & Hosting</h3>
                    <a href="services.php" class="product-offer-link" style="font-size: 0.85rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">READ MORE →</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="product-offer-card" style="background: #f8fafb; border-radius: 16px; padding: 30px 20px 25px; text-align: center; height: 100%;">
                    <div class="product-offer-icon" style="font-size: 2.8rem; color: var(--kilele-primary); margin-bottom: 16px;"><i class="fas fa-video"></i></div>
                    <h3 class="product-offer-title" style="font-size: 1.1rem; font-weight: 700; color: var(--kilele-navy); margin-bottom: 12px;">CCTV & Security Systems</h3>
                    <a href="services.php" class="product-offer-link" style="font-size: 0.85rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">READ MORE →</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="product-offer-card" style="background: #f8fafb; border-radius: 16px; padding: 30px 20px 25px; text-align: center; height: 100%;">
                    <div class="product-offer-icon" style="font-size: 2.8rem; color: var(--kilele-primary); margin-bottom: 16px;"><i class="fas fa-clipboard-list"></i></div>
                    <h3 class="product-offer-title" style="font-size: 1.1rem; font-weight: 700; color: var(--kilele-navy); margin-bottom: 12px;">ICT Consulting</h3>
                    <a href="services.php" class="product-offer-link" style="font-size: 0.85rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">READ MORE →</a>
                </div>
            </div>
        </div>

        <div class="text-center mt-4">
            <p style="font-size: 1.05rem; color: var(--kilele-text-light); max-width: 680px; margin: 0 auto 20px; line-height: 1.7;">
                Plus hardware supply & installation, ICT consulting, database management, security monitoring, and firewall solutions — 8 services in total.
            </p>
            <a href="services.php" class="btn btn-kilele-primary" style="padding: 12px 40px; border-radius: 50px; font-weight: 600;">View All Services →</a>
        </div>
    </div>
</section>

<!-- ============================================================
WHY CHOOSE US — real value proposition from the company profile
============================================================ -->
<section class="why-choose-us-section">
    <div class="container">
        <div class="why-choose-us__header">
            <span class="why-choose-us__eyebrow">OUR VALUE PROPOSITION</span>
            <h2 class="why-choose-us__heading">Why clients choose Kilele Tech</h2>
            <p class="why-choose-us__subcopy">
                Founded in August 2025, we've delivered 100+ projects with 100% client satisfaction across
                8 service areas — for businesses, government agencies and non-profits.
            </p>
            <a href="quote.php" class="btn btn-kilele-primary why-choose-us__cta">Get a Free Consultation →</a>
        </div>

        <div class="why-choose-us__grid">
            <div class="why-choose-us__card">
                <span class="why-choose-us__number">01</span>
                <div class="why-choose-us__icon"><i class="fas fa-bolt"></i></div>
                <h3>Technical Excellence</h3>
                <p>Our team stays ahead of the curve with the latest technologies and industry best practices.</p>
            </div>

            <div class="why-choose-us__divider"></div>

            <div class="why-choose-us__card">
                <span class="why-choose-us__number">02</span>
                <div class="why-choose-us__icon"><i class="fas fa-shield-halved"></i></div>
                <h3>Security First</h3>
                <p>We build security into every solution — from development to deployment.</p>
            </div>

            <div class="why-choose-us__divider"></div>

            <div class="why-choose-us__card">
                <span class="why-choose-us__number">03</span>
                <div class="why-choose-us__icon"><i class="fas fa-people-arrows"></i></div>
                <h3>Client-Centric Approach</h3>
                <p>We listen to your needs, understand your business, and deliver solutions that drive real results.</p>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================
BUNDLE & SAVE — repurposed from Punguza Mizigo
============================================================ -->
<section class="punguza-section">
    <div class="container">
        <div class="row align-items-center g-4">
            <div class="col-lg-7">
                <h2 class="punguza-title">One Partner, All Your ICT Needs</h2>
                <p class="punguza-subtitle">"Stop juggling five vendors for one IT setup."</p>
                <p style="opacity: 0.8;">Bundle your <strong style="color: var(--kilele-yellow);">software, hosting, security and support</strong> under one contract.</p>
                <p style="opacity: 0.8;">You get one point of contact, one SLA, and one team that already knows your systems.</p>
                <p style="color: var(--kilele-yellow); font-weight: 600; font-size: 1.1rem;">Lower overall cost. Faster response. Less coordination overhead.</p>
                <ul class="punguza-features">
                    <li><i class="fas fa-check-circle"></i> Combine multiple services into one support contract</li>
                    <li><i class="fas fa-check-circle"></i> Lower bundled pricing vs. hiring separately</li>
                    <li><i class="fas fa-check-circle"></i> SLA-based support with 24/7 monitoring</li>
                    <li><i class="fas fa-check-circle"></i> One team accountable for your whole stack</li>
                </ul>
                <a href="quote.php" class="btn-hero-primary" style="background: var(--kilele-yellow); color: #333; border: none; padding: 12px 35px; border-radius: 50px; font-weight: 600;">Get a Bundled Quote</a>
            </div>
            <div class="col-lg-5 text-center">
                <div style="background: rgba(255,255,255,0.05); border-radius: 20px; padding: 40px; border: 1px solid rgba(255,255,255,0.08);">
                    <div style="font-size: 4rem; color: var(--kilele-yellow);">🛡️</div>
                    <h3 style="color: white; margin-top: 15px;">8 SERVICES</h3>
                    <p style="color: rgba(255,255,255,0.6);">One partner for all of them</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================
SERVICE PACKAGES — repurposed from Membership tiers
============================================================ -->
<section class="membership-section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Service Packages</h2>
            <p class="section-description">
                Whatever stage your business is at — explore <strong>Starter, Business and Enterprise</strong> to find the package that suits you.
            </p>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="membership-card">
                    <div class="membership-icon"><i class="fas fa-seedling"></i></div>
                    <h4>Starter</h4>
                    <p>For small businesses that need a website, basic hardware setup, and occasional support.</p>
                    <span class="membership-badge">Small Business</span>
                </div>
            </div>
            <div class="col-md-4">
                <div class="membership-card">
                    <div class="membership-icon"><i class="fas fa-briefcase"></i></div>
                    <h4>Business</h4>
                    <p>For growing teams needing custom software, security monitoring, and SLA-backed support.</p>
                    <span class="membership-badge">Growing Teams</span>
                </div>
            </div>
            <div class="col-md-4">
                <div class="membership-card">
                    <div class="membership-icon"><i class="fas fa-building"></i></div>
                    <h4>Enterprise</h4>
                    <p>Full ICT partnership — consulting, infrastructure, 24/7 monitoring and dedicated project teams.</p>
                    <span class="membership-badge">Full ICT Partner</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================
TALK TO OUR TEAM — repurposed from Join Us contact grid
============================================================ -->
<section class="join-us-section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 style="color: white; font-weight: 700; font-size: 2.5rem;">Talk to Our Team</h2>
            <p style="color: rgba(255,255,255,0.7);">Reach the right department directly for faster answers.</p>
        </div>

        <div class="row g-4">
            <div class="col-md-3 col-6">
                <div class="contact-card">
                    <div class="contact-icon"><i class="fas fa-handshake"></i></div>
                    <h5>Sales & New Business</h5>
                    <p>+254 757 111 222</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="contact-card">
                    <div class="contact-icon"><i class="fas fa-headset"></i></div>
                    <h5>Technical Support</h5>
                    <p>+254 757 111 222</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="contact-card">
                    <div class="contact-icon"><i class="fas fa-shield-halved"></i></div>
                    <h5>Security Consulting</h5>
                    <p>+254 757 111 222</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="contact-card">
                    <div class="contact-icon"><i class="fas fa-diagram-project"></i></div>
                    <h5>Project Management</h5>
                    <p>+254 757 111 222</p>
                </div>
            </div>
        </div>

        <div class="text-center mt-5">
            <p style="color: rgba(255,255,255,0.6); font-size: 14px;">
                <i class="fas fa-phone me-2"></i> Call us for more information
            </p>
            <a href="contact.php" class="btn btn-kilele-primary">Get in Touch</a>
        </div>
    </div>
</section>

<!-- ============================================================
FIND US
============================================================ -->
<section class="section-padding" style="background: #f8f9fa;" id="map">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-5">
                <h2 class="section-title" style="font-size: 2rem;">Find Us</h2>
                <p>Drop by to discuss your next ICT project or scope out a free consultation.</p>

                <div class="location-card">
                    <p><i class="fas fa-location-dot me-2"></i> University of Nairobi, Main Campus</p>
                    <p><i class="fas fa-phone me-2"></i> +254 757 111 222</p>
                    <p><i class="fas fa-envelope me-2"></i> kileletechofficial@gmail.com</p>
                    <a href="https://www.google.com/maps/search/chuna+sacco+location/@-1.2779773,36.8144774,17z?entry=s&sa=X&ved=1t%3A199789" target="_blank" rel="noopener" class="btn btn-kilele-primary mt-3">Get Directions →</a>

                <div class="location-card">
                    <h5><i class="fas fa-comment me-2"></i> Feedback</h5>
                    <p>We value your feedback. Let us know how we can serve you better.</p>
                    <a href="contact.php" class="btn btn-kilele-outline" style="color: var(--kilele-primary); border-color: var(--kilele-primary);">Send Feedback</a>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="map-placeholder">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.7632!2d36.8144774!3d-1.2779773!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sChuna+Sacco!5e0!3m2!1sen!2ske!4v1710000000000"
                     allowfullscreen=""
                     loading="lazy"
                     referrerpolicy="no-referrer-when-downgrade"
                     title="Chuna Sacco Location"
                     style="width: 100%; height: 100%; border: 0;">
                </iframe>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SLIDER PAUSE-ON-HOVER & SPEED CONTROL -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const heroTrack = document.getElementById('heroTrack');
        const heroNext = document.getElementById('heroNext');
        const heroPrev = document.getElementById('heroPrev');

        // Safety check: if elements don't exist, stop running
        if (!heroTrack || !heroNext) return;

        let autoSlideInterval;

        // Function to start the auto-slide
        function startAutoSlide() {
            if (autoSlideInterval) clearInterval(autoSlideInterval);
            autoSlideInterval = setInterval(() => {
                heroNext.click();
            }, 3500); // Change this number to adjust speed. 3500 = 3.5 seconds.
        }

        // Function to stop the auto-slide
        function stopAutoSlide() {
            if (autoSlideInterval) {
                clearInterval(autoSlideInterval);
                autoSlideInterval = null;
            }
        }

        // 1. Start the slider immediately
        startAutoSlide();

        // 2. Pause whenever your mouse hovers over the slider
        heroTrack.addEventListener('mouseenter', stopAutoSlide);
        heroTrack.addEventListener('touchstart', stopAutoSlide); // For mobile phones

        // 3. Restart whenever your mouse leaves the slider
        heroTrack.addEventListener('mouseleave', startAutoSlide);
        heroTrack.addEventListener('touchend', startAutoSlide); // For mobile phones
    });
</script>


<?php include 'includes/footer.php'; ?>
