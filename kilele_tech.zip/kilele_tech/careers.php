<?php
$pageTitle = 'Careers – KileleTech';
include 'includes/header.php';
?>

<section class="page-hero" style="background: linear-gradient(135deg, #0f1e33 0%, #1a2d47 100%);">
    <div class="container">
        <div class="page-hero__breadcrumb"><a href="index.php">Home</a> / About Us / Careers</div>
        <h1 class="page-hero__title">Careers at KileleTech</h1>
        <p class="page-hero__subtitle">
            Join our team and help us build technology solutions that drive growth across Africa.
        </p>
    </div>
</section>

<!-- Why Work With Us -->
<section class="content-section">
    <div class="container">
        <div class="text-center mb-5">
            <span class="why-choose-us__eyebrow">Why Join Us</span>
            <h2 class="why-choose-us__heading">Work with purpose</h2>
            <p class="why-choose-us__subcopy" style="margin-left:auto; margin-right:auto;">
                At KileleTech, we believe in building technology that makes a difference. Join a team of passionate innovators
                who are shaping the future of ICT in Kenya and beyond.
            </p>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="membership-card" style="height:100%;">
                    <div class="membership-icon"><i class="fas fa-rocket" style="color: var(--kilele-primary);"></i></div>
                    <h4>Innovation First</h4>
                    <p>Work with the latest technologies — from AI to cloud computing, we're always pushing boundaries.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="membership-card" style="height:100%;">
                    <div class="membership-icon"><i class="fas fa-users" style="color: var(--kilele-primary);"></i></div>
                    <h4>Collaborative Culture</h4>
                    <p>We believe in teamwork, mentorship, and growing together. Your ideas matter here.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="membership-card" style="height:100%;">
                    <div class="membership-icon"><i class="fas fa-chart-line" style="color: var(--kilele-primary);"></i></div>
                    <h4>Growth & Impact</h4>
                    <p>We invest in your professional development and give you work that makes a real difference.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Current Openings -->
<section class="content-section content-section--alt">
    <div class="container">
        <div class="text-center mb-5">
            <span class="why-choose-us__eyebrow">Open Positions</span>
            <h2 class="why-choose-us__heading">Join our team</h2>
            <p class="why-choose-us__subcopy" style="margin-left:auto; margin-right:auto;">
                We're looking for talented individuals who share our passion for technology and innovation.
            </p>
        </div>

        <div class="row g-4">
            <!-- Job 1 -->
            <div class="col-md-6">
                <div class="job-card" style="background: #fff; border-radius: 16px; padding: 28px; box-shadow: 0 5px 20px rgba(0,0,0,0.06); border-left: 4px solid var(--kilele-primary);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 8px;">
                        <h4 style="font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px;">Senior Software Developer</h4>
                        <span style="background: var(--kilele-primary); color: #fff; padding: 4px 14px; border-radius: 50px; font-size: 12px; font-weight: 600;">Full-time</span>
                    </div>
                    <p style="color: var(--kilele-text-light); font-size: 0.9rem; margin: 4px 0 12px;">
                        <i class="fas fa-map-marker-alt" style="color: var(--kilele-primary);"></i> Nairobi, Kenya
                    </p>
                    <p style="color: var(--kilele-text-light); font-size: 0.95rem; line-height: 1.6;">
                        Lead development of custom software solutions for enterprise clients. Requires 5+ years experience in PHP, Python, or Java, and expertise in ERP systems.
                    </p>
                    <div style="display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0;">
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">PHP</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">Python</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">ERP 365</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">Cloud</span>
                    </div>
                    <a href="#" class="btn btn-kilele-primary" style="padding: 8px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; background: var(--kilele-primary); color: #fff; text-decoration: none; display: inline-block;">Apply Now</a>
                </div>
            </div>

            <!-- Job 2 -->
            <div class="col-md-6">
                <div class="job-card" style="background: #fff; border-radius: 16px; padding: 28px; box-shadow: 0 5px 20px rgba(0,0,0,0.06); border-left: 4px solid var(--kilele-yellow);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 8px;">
                        <h4 style="font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px;">Security Systems Engineer</h4>
                        <span style="background: var(--kilele-yellow); color: #333; padding: 4px 14px; border-radius: 50px; font-size: 12px; font-weight: 600;">Full-time</span>
                    </div>
                    <p style="color: var(--kilele-text-light); font-size: 0.9rem; margin: 4px 0 12px;">
                        <i class="fas fa-map-marker-alt" style="color: var(--kilele-primary);"></i> Nairobi, Kenya
                    </p>
                    <p style="color: var(--kilele-text-light); font-size: 0.95rem; line-height: 1.6;">
                        Design and implement CCTV, access control, firewall, and security monitoring solutions. Requires 3+ years experience in network security and hardware installation.
                    </p>
                    <div style="display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0;">
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">CCTV</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">Firewall</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">Network Security</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">Fortinet</span>
                    </div>
                    <a href="#" class="btn btn-kilele-primary" style="padding: 8px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; background: var(--kilele-primary); color: #fff; text-decoration: none; display: inline-block;">Apply Now</a>
                </div>
            </div>

            <!-- Job 3 -->
            <div class="col-md-6">
                <div class="job-card" style="background: #fff; border-radius: 16px; padding: 28px; box-shadow: 0 5px 20px rgba(0,0,0,0.06); border-left: 4px solid var(--kilele-coral);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 8px;">
                        <h4 style="font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px;">ICT Consultant</h4>
                        <span style="background: var(--kilele-coral); color: #fff; padding: 4px 14px; border-radius: 50px; font-size: 12px; font-weight: 600;">Remote</span>
                    </div>
                    <p style="color: var(--kilele-text-light); font-size: 0.9rem; margin: 4px 0 12px;">
                        <i class="fas fa-globe" style="color: var(--kilele-primary);"></i> Remote (Kenya based)
                    </p>
                    <p style="color: var(--kilele-text-light); font-size: 0.95rem; line-height: 1.6;">
                        Provide expert IT strategy, digital transformation, and system integration advice to clients. Requires 5+ years consulting experience.
                    </p>
                    <div style="display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0;">
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">IT Strategy</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">Digital Transformation</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">System Integration</span>
                    </div>
                    <a href="#" class="btn btn-kilele-primary" style="padding: 8px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; background: var(--kilele-primary); color: #fff; text-decoration: none; display: inline-block;">Apply Now</a>
                </div>
            </div>

            <!-- Job 4 -->
            <div class="col-md-6">
                <div class="job-card" style="background: #fff; border-radius: 16px; padding: 28px; box-shadow: 0 5px 20px rgba(0,0,0,0.06); border-left: 4px solid var(--kilele-navy);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 8px;">
                        <h4 style="font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px;">Database Administrator</h4>
                        <span style="background: var(--kilele-navy); color: #fff; padding: 4px 14px; border-radius: 50px; font-size: 12px; font-weight: 600;">Full-time</span>
                    </div>
                    <p style="color: var(--kilele-text-light); font-size: 0.9rem; margin: 4px 0 12px;">
                        <i class="fas fa-map-marker-alt" style="color: var(--kilele-primary);"></i> Nairobi, Kenya
                    </p>
                    <p style="color: var(--kilele-text-light); font-size: 0.95rem; line-height: 1.6;">
                        Manage and optimize database systems for enterprise clients. Requires 3+ years experience in MySQL, PostgreSQL, or Oracle.
                    </p>
                    <div style="display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0;">
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">MySQL</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">PostgreSQL</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">Performance Tuning</span>
                        <span style="background: rgba(41,160,142,0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 12px; font-weight: 600;">Backup & Recovery</span>
                    </div>
                    <a href="#" class="btn btn-kilele-primary" style="padding: 8px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; background: var(--kilele-primary); color: #fff; text-decoration: none; display: inline-block;">Apply Now</a>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- How to Apply -->
<section class="content-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div style="background: #f8fafb; border-radius: 16px; padding: 36px; text-align: center;">
                    <h3 style="font-weight: 700; color: var(--kilele-navy); margin-bottom: 12px;">How to Apply</h3>
                    <p style="color: var(--kilele-text-light); max-width: 560px; margin: 0 auto 20px;">
                        Send your CV and a brief cover letter to <strong style="color: var(--kilele-primary);">careers@kileletech.com</strong>
                        with the job title as the subject line.
                    </p>
                    <a href="mailto:careers@kileletech.com" style="display: inline-block; padding: 14px 40px; border-radius: 50px; font-weight: 600; background: var(--kilele-primary); color: #fff; text-decoration: none; transition: 0.3s;">
                        <i class="fas fa-envelope me-2"></i> Apply Now
                    </a>
                    <p style="color: var(--kilele-text-light); font-size: 0.85rem; margin-top: 16px;">
                        We'll review applications within 5 business days. Only shortlisted candidates will be contacted.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>