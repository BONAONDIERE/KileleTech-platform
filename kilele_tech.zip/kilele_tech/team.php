<?php
$pageTitle = 'Our Team – KileleTech';
include 'includes/header.php';
?>

<!-- ============================================================
   PAGE HERO – Uses global styles from layout.css
   ============================================================ -->
<section class="page-hero">
    <div class="container">
        <div class="page-hero__breadcrumb"><a href="index.php">Home</a> / About Us / Our Team</div>
        <h1 class="page-hero__title">Our ICT Team</h1>
        <p class="page-hero__subtitle">
            The talented professionals behind KileleTech's technology solutions.
        </p>
    </div>
</section>

<!-- ============================================================
   ICT TEAM
   ============================================================ -->
<section class="content-section" style="padding: 20px 0 50px;">
    <div class="container">
        
        <!-- Compact introduction -->
        <div style="text-align: center; margin-bottom: 25px; max-width: 600px; margin-left: auto; margin-right: auto;">
            <p style="color: var(--kilele-text-light); font-size: 0.95rem; line-height: 1.6; margin: 0;">
                <span style="font-weight: 700; color: var(--kilele-navy);">Meet the team</span> — a passionate group of ICT professionals dedicated to delivering innovative technology solutions.
            </p>
        </div>

        <div class="team-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 30px;">

            <!-- Erick Bundi -->
            <div class="team-card" data-id="1" data-color="teal" style="background: #fff; border-radius: 16px; padding: 30px 20px 24px; text-align: center; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; border-top: 4px solid var(--kilele-primary); cursor: pointer; position: relative;">
                <div class="team-card__avatar" style="width: 120px; height: 120px; border-radius: 50%; overflow: hidden; margin: 0 auto 16px; transition: 0.3s; border: 4px solid var(--kilele-primary);">
                    <img src="images/team/erickbundi.png" alt="Erick Bundi" style="width: 100%; height: 100%; object-fit: cover;">
                </div>
                <h4 style="font-size: 1.1rem; font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px;">Erick Bundi</h4>
                <span style="display: inline-block; font-size: 13px; font-weight: 600; color: var(--kilele-primary); background: rgba(41, 160, 142, 0.1); padding: 4px 16px; border-radius: 50px; margin-bottom: 10px;">ICT Manager</span>
                <p style="font-size: 0.9rem; color: var(--kilele-text-light); margin: 0; line-height: 1.5;">
                    Leads the ICT team, oversees infrastructure, and ensures delivery of technology solutions.
                </p>
                <div style="margin-top: 12px; font-size: 12px; color: var(--kilele-primary); font-weight: 600;">
                    Click to learn more <i class="fas fa-arrow-right ms-1"></i>
                </div>
            </div>

            <!-- Joseph Kinuthia -->
            <div class="team-card" data-id="2" data-color="yellow" style="background: #fff; border-radius: 16px; padding: 30px 20px 24px; text-align: center; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; border-top: 4px solid var(--kilele-yellow); cursor: pointer; position: relative;">
                <div class="team-card__avatar" style="width: 120px; height: 120px; border-radius: 50%; overflow: hidden; margin: 0 auto 16px; transition: 0.3s; border: 4px solid var(--kilele-yellow);">
                    <img src="images/team/josephkinuthia.png" alt="Joseph Kinuthia" style="width: 100%; height: 100%; object-fit: cover;">
                </div>
                <h4 style="font-size: 1.1rem; font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px;">Joseph Kinuthia</h4>
                <span style="display: inline-block; font-size: 13px; font-weight: 600; color: var(--kilele-yellow); background: rgba(242, 185, 30, 0.15); padding: 4px 16px; border-radius: 50px; margin-bottom: 10px;">ICT Assistant</span>
                <p style="font-size: 0.9rem; color: var(--kilele-text-light); margin: 0; line-height: 1.5;">
                    Supports ICT operations, troubleshooting, and system maintenance for clients.
                </p>
                <div style="margin-top: 12px; font-size: 12px; color: var(--kilele-primary); font-weight: 600;">
                    Click to learn more <i class="fas fa-arrow-right ms-1"></i>
                </div>
            </div>

            <!-- Ruth Bonareri -->
            <div class="team-card" data-id="3" data-color="coral" style="background: #fff; border-radius: 16px; padding: 30px 20px 24px; text-align: center; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; border-top: 4px solid var(--kilele-coral); cursor: pointer; position: relative;">
                <div class="team-card__avatar" style="width: 120px; height: 120px; border-radius: 50%; overflow: hidden; margin: 0 auto 16px; transition: 0.3s; border: 4px solid var(--kilele-coral);">
                    <img src="images/team/ruthbonareri.png" alt="Ruth Bonareri" style="width: 100%; height: 100%; object-fit: cover;">
                </div>
                <h4 style="font-size: 1.1rem; font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px;">Ruth Bonareri</h4>
                <span style="display: inline-block; font-size: 13px; font-weight: 600; color: var(--kilele-coral); background: rgba(201, 88, 115, 0.12); padding: 4px 16px; border-radius: 50px; margin-bottom: 10px;">ICT Intern</span>
                <p style="font-size: 0.9rem; color: var(--kilele-text-light); margin: 0; line-height: 1.5;">
                    Supports ICT projects, system administration, and client support services.
                </p>
                <div style="margin-top: 12px; font-size: 12px; color: var(--kilele-primary); font-weight: 600;">
                    Click to learn more <i class="fas fa-arrow-right ms-1"></i>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ============================================================
   TEAM MEMBER MODAL
   ============================================================ -->
<div id="teamModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 9999; justify-content: center; align-items: center; padding: 20px;">
    <div style="background: #fff; border-radius: 18px; padding: 35px; max-width: 500px; width: 100%; max-height: 90vh; overflow-y: auto; position: relative; animation: modalFadeIn 0.3s ease;">
        <button onclick="closeModal()" style="position: absolute; top: 12px; right: 18px; background: none; border: none; font-size: 28px; color: #999; cursor: pointer; transition: 0.3s;">&times;</button>
        <div id="modalContent"></div>
    </div>
</div>

<script>
const teamData = [
    {
        id: 1,
        name: 'Erick Bundi',
        role: 'ICT Manager',
        avatar: 'EB',
        image: 'images/team/erickbundi.png',
        color: 'teal',
        bio: 'Erick is the ICT Manager at KileleTech, playing a pivotal role in shaping our technological landscape and driving innovation. With a wealth of experience and expertise in information and communication technology, he spearheads various initiatives aimed at enhancing efficiency, productivity, and client satisfaction.\n\nNetwork Management and System Administration: Erick\'s proficiency ensures the seamless operation of our ICT infrastructure. His strategic oversight guarantees that our networks remain robust, secure, and optimized for performance.\n\nDatabase Management: As the custodian of our data assets, Erick meticulously manages our databases, safeguarding the integrity, confidentiality, and availability of critical information while ensuring compliance with regulatory standards.\n\nUser Support and Stakeholder Engagement: Erick provides timely assistance and guidance to our staff and clients, ensuring they maximize the benefits of our ICT systems. He fosters strong relationships with internal teams, external vendors, and regulatory bodies.\n\nRapid Innovation and Development: Erick\'s visionary leadership is evident in his relentless pursuit of innovation by harnessing emerging technologies and fostering a culture of creativity and collaboration.',
        qualifications: ['BSc Information Technology', 'MSc Data Analytics', 'CCNA Certified', 'HCA Certified', 'Ethical Hacking Certified'],
        skills: ['IT Management', 'Network Administration', 'Database Management', 'Infrastructure', 'Project Management', 'Leadership', 'Network Security', 'Data Analytics', 'Stakeholder Engagement'],
        email: 'erick@kileletech.com',
        phone: '+254 111 222 226'
    },
    {
        id: 2,
        name: 'Joseph Kinuthia',
        role: 'ICT Assistant',
        avatar: 'JK',
        image: 'images/team/josephkinuthia.png',
        color: 'yellow',
        bio: 'Joseph is an IT and Telecommunications Technician dedicated to building efficient, secure, and reliable digital systems that help organizations operate smoothly and scale confidently. With a strong foundation in network support, system maintenance, and user assistance, he focuses on solving real-world challenges with practical, sustainable technology solutions. He believes that growth comes from action — "The world doesn\'t reward those who wait to be ready; it rewards those who begin before they are." That principle drives how he approaches both technology and teamwork — proactive, results-driven, and always learning. He holds a BTech in Electrical and Electronics Engineering.',
        qualifications: ['BTech Electrical and Electronics Engineering'],
        skills: ['Network Support', 'System Maintenance', 'User Assistance', 'Troubleshooting', 'IT Operations'],
        email: 'joseph@kileletech.com',
        phone: '+254 111 222 227'
    },
    {
        id: 3,
        name: 'Ruth Bonareri',
        role: 'ICT Intern',
        avatar: 'RB',
        image: 'images/team/ruthbonareri.png',
        color: 'coral',
        bio: 'Ruth is an ICT Intern at KileleTech, supporting ICT projects, system administration, and client services. She has a background in Electronics and Computer Engineering and is currently pursuing a Masters in Technology Management and Artificial Intelligence. She is passionate about technology and has expertise in software development, data analysis, data science, and machine learning and AI.',
        qualifications: ['BSc Electronics and Computer Engineering', 'MSc Technology Management & AI (ongoing)'],
        skills: ['Software Development', 'Data Analysis', 'Data Science', 'Machine Learning', 'AI', 'System Support'],
        email: 'ruth@kileletech.com',
        phone: '+254 111 222 228'
    }
];

function openModal(id) {
    const member = teamData.find(m => m.id === id);
    if (!member) return;

    const modal = document.getElementById('teamModal');
    const content = document.getElementById('modalContent');

    const qualificationsHtml = member.qualifications.map(qual => 
        `<span style="display: inline-block; background: rgba(41, 160, 142, 0.08); color: var(--kilele-primary); padding: 4px 12px; border-radius: 50px; font-size: 11px; font-weight: 600; margin: 3px 4px 3px 0;">${qual}</span>`
    ).join('');

    const skillsHtml = member.skills.map(skill => 
        `<span style="display: inline-block; background: rgba(201, 88, 115, 0.08); color: var(--kilele-coral); padding: 4px 12px; border-radius: 50px; font-size: 11px; font-weight: 600; margin: 3px 4px 3px 0;">${skill}</span>`
    ).join('');

    const bioHtml = member.bio.replace(/\n\n/g, '</p><p style="color: var(--kilele-text-light); line-height: 1.7; font-size: 0.9rem; margin-bottom: 10px;">').replace(/\n/g, '<br>');

    content.innerHTML = `
        <div style="text-align: center; margin-bottom: 16px;">
            <div style="width: 100px; height: 100px; border-radius: 50%; overflow: hidden; margin: 0 auto 14px; border: 3px solid var(--kilele-primary);">
                <img src="${member.image}" alt="${member.name}" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
            <h3 style="font-size: 1.4rem; font-weight: 700; color: var(--kilele-navy); margin-bottom: 2px;">${member.name}</h3>
            <span style="display: inline-block; font-size: 13px; font-weight: 600; color: var(--kilele-primary); background: rgba(41, 160, 142, 0.1); padding: 4px 16px; border-radius: 50px; margin-bottom: 10px;">
                ${member.role}
            </span>
        </div>

        <div style="margin-bottom: 14px;">
            <h5 style="font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px; font-size: 0.95rem;">About</h5>
            <p style="color: var(--kilele-text-light); line-height: 1.7; font-size: 0.9rem; margin-bottom: 8px;">${bioHtml}</p>
        </div>

        <div style="margin-bottom: 14px;">
            <h5 style="font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px; font-size: 0.95rem;">Qualifications</h5>
            <div>${qualificationsHtml}</div>
        </div>

        <div style="margin-bottom: 14px;">
            <h5 style="font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px; font-size: 0.95rem;">Skills & Expertise</h5>
            <div>${skillsHtml}</div>
        </div>

        <div style="border-top: 1px solid #eee; padding-top: 14px;">
            <h5 style="font-weight: 700; color: var(--kilele-navy); margin-bottom: 4px; font-size: 0.95rem;">Connect</h5>
            <p style="color: var(--kilele-text-light); font-size: 0.85rem; margin: 2px 0;">
                <i class="fas fa-envelope" style="color: var(--kilele-primary); width: 24px;"></i> 
                <a href="mailto:${member.email}" style="color: var(--kilele-text-light); text-decoration: none;">${member.email}</a>
            </p>
            <p style="color: var(--kilele-text-light); font-size: 0.85rem; margin: 2px 0;">
                <i class="fas fa-phone" style="color: var(--kilele-primary); width: 24px;"></i> 
                ${member.phone}
            </p>
        </div>

        <div style="margin-top: 16px; text-align: center;">
            <button onclick="closeModal()" style="padding: 8px 32px; border-radius: 50px; font-weight: 600; background: var(--kilele-primary); color: #fff; border: none; cursor: pointer; transition: 0.3s; font-size: 0.9rem;">
                Close
            </button>
        </div>
    `;

    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    document.getElementById('teamModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

document.addEventListener('DOMContentLoaded', function() {
    const cards = document.querySelectorAll('.team-card');
    cards.forEach(card => {
        const id = parseInt(card.dataset.id);
        card.addEventListener('click', function() {
            openModal(id);
        });
    });

    document.getElementById('teamModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    });
});
</script>

<style>
@keyframes modalFadeIn {
    from { opacity: 0; transform: scale(0.95) translateY(-15px); }
    to { opacity: 1; transform: scale(1) translateY(0); }
}

.team-card[data-color="teal"]:hover { border-top-color: var(--kilele-primary); }
.team-card[data-color="yellow"]:hover { border-top-color: var(--kilele-yellow); }
.team-card[data-color="coral"]:hover { border-top-color: var(--kilele-coral); }

.team-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.1);
}
.team-card:hover .team-card__avatar {
    transform: scale(1.05);
    border-color: var(--kilele-primary) !important;
}

@media (max-width: 768px) {
    .team-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 20px !important; }
}
@media (max-width: 480px) {
    .team-grid { grid-template-columns: 1fr !important; }
    .team-card__avatar { width: 80px !important; height: 80px !important; }
    #teamModal > div { padding: 24px; margin: 10px; }
}
</style>

<?php include 'includes/footer.php'; ?>