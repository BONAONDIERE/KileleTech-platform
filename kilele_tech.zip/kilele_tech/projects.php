<?php
$pageTitle = 'Projects';
include 'includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <div class="page-hero__breadcrumb"><a href="index.php">Home</a> / Projects</div>
        <h1 class="page-hero__title">Our Projects</h1>
        <p class="page-hero__subtitle">
            A look at recent and ongoing work across software, security, and infrastructure.
        </p>
    </div>
</section>

<section class="content-section">
    <div class="container">
        <div class="tender-list">
            <div class="tender-item">
                <div class="tender-item__info">
                    <h5>County Government Whistle-Blowing Platform</h5>
                    <p>Secure web platform for anonymous reporting, built on Laravel with end-to-end encryption.</p>
                </div>
                <div class="d-flex align-items-center gap-3">
                    <span class="tender-item__deadline"><i class="fas fa-calendar me-1"></i> Delivered Jun 2026</span>
                    <span class="tender-item__status tender-item__status--closed">Completed</span>
                </div>
            </div>
            <div class="tender-item">
                <div class="tender-item__info">
                    <h5>NGO Head Office CCTV & Access Control Upgrade</h5>
                    <p>Full IP camera installation with biometric access control across a 4-floor office building.</p>
                </div>
                <div class="d-flex align-items-center gap-3">
                    <span class="tender-item__deadline"><i class="fas fa-calendar me-1"></i> Delivered Apr 2026</span>
                    <span class="tender-item__status tender-item__status--closed">Completed</span>
                </div>
            </div>
            <div class="tender-item">
                <div class="tender-item__info">
                    <h5>Retail Chain ERP Rollout</h5>
                    <p>Multi-branch ERP deployment with inventory sync, currently in the testing and training phase.</p>
                </div>
                <div class="d-flex align-items-center gap-3">
                    <span class="tender-item__deadline"><i class="fas fa-calendar me-1"></i> Target Sep 2026</span>
                    <span class="tender-item__status tender-item__status--open">Ongoing</span>
                </div>
            </div>
            <div class="tender-item">
                <div class="tender-item__info">
                    <h5>Financial Services Firewall & SIEM Deployment</h5>
                    <p>Enterprise firewall rollout with 24/7 SIEM monitoring for a mid-sized financial institution.</p>
                </div>
                <div class="d-flex align-items-center gap-3">
                    <span class="tender-item__deadline"><i class="fas fa-calendar me-1"></i> Target Oct 2026</span>
                    <span class="tender-item__status tender-item__status--open">Ongoing</span>
                </div>
            </div>
        </div>

        <div class="text-center mt-5">
            <p style="color: var(--kilele-text-light); font-size: 1rem;">Have a similar project in mind?</p>
            <a href="quote.php" class="btn-hero-primary">Start a Project →</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
