<?php
$pageTitle = 'Services – KileleTech';
include 'includes/header.php';
?>

<!-- ============================================================
   PAGE HERO – Uses global styles from layout.css
   ============================================================ -->
<section class="page-hero">
    <div class="container">
        <div class="page-hero__breadcrumb"><a href="index.php">Home</a> / Services</div>
        <h1 class="page-hero__title">Our ICT Services</h1>
        <p class="page-hero__subtitle">
            End-to-end technology solutions — from software development to security monitoring.
        </p>
    </div>
</section>

<!-- ============================================================
   SERVICES GRID
   ============================================================ -->
<section class="content-section" style="padding: 30px 0 50px;">
    <div class="container">
        <div class="text-center mb-5">
            <span class="why-choose-us__eyebrow">8 Service Areas</span>
            <h2 class="why-choose-us__heading">Whatever you need, we build it in-house</h2>
        </div>

        <div class="product-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 26px;">

            <!-- ============ 1. Software Development ============ -->
            <div class="product-card" style="background: #fff; border-radius: 18px; overflow: hidden; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; display: flex; flex-direction: column;">
                <div class="product-card__banner product-card__banner--teal" style="padding: 26px; color: white; background: linear-gradient(135deg, var(--kilele-primary), var(--kilele-primary-dark));">
                    <i class="fas fa-code" style="font-size: 1.8rem; margin-bottom: 10px; display: block;"></i>
                    <h3 style="font-size: 1.15rem; font-weight: 700; margin: 0;">Software Development</h3>
                </div>
                <div class="product-card__body" style="padding: 22px 24px 26px; flex: 1; display: flex; flex-direction: column;">
                    <p style="font-size: 0.9rem; color: var(--kilele-text-light); line-height: 1.6; margin-bottom: 16px;">
                        Custom software solutions — from mobile apps to enterprise ERP systems (2018, 365). We design, build, and deploy scalable applications tailored to your business needs.
                    </p>
                    <ul style="list-style: none; padding: 0; margin: 0 0 18px; font-size: 0.82rem; color: var(--kilele-text-dark);">
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Expertise</span> <span style="font-weight: 700; color: var(--kilele-navy);">ERP, Web, Mobile</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Also covers</span> <span style="font-weight: 700; color: var(--kilele-navy);">APIs, Custom Dev</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Pricing</span> <span style="font-weight: 700; color: var(--kilele-navy);">Custom quote</span></li>
                    </ul>
                    <a href="quote.php" style="margin-top: auto; display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">Get a Quote <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>

            <!-- ============ 2. Web Development & Hosting ============ -->
            <div class="product-card" style="background: #fff; border-radius: 18px; overflow: hidden; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; display: flex; flex-direction: column;">
                <div class="product-card__banner product-card__banner--yellow" style="padding: 26px; color: #333; background: linear-gradient(135deg, var(--kilele-yellow), #d99f10);">
                    <i class="fas fa-globe" style="font-size: 1.8rem; margin-bottom: 10px; display: block;"></i>
                    <h3 style="font-size: 1.15rem; font-weight: 700; margin: 0;">Web Development & Hosting</h3>
                </div>
                <div class="product-card__body" style="padding: 22px 24px 26px; flex: 1; display: flex; flex-direction: column;">
                    <p style="font-size: 0.9rem; color: var(--kilele-text-light); line-height: 1.6; margin-bottom: 16px;">
                        Fast, secure, and mobile-responsive websites for businesses, NGOs, and government agencies. Hosting includes 99.9% uptime, security monitoring and regular backups.
                    </p>
                    <ul style="list-style: none; padding: 0; margin: 0 0 18px; font-size: 0.82rem; color: var(--kilele-text-dark);">
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Expertise</span> <span style="font-weight: 700; color: var(--kilele-navy);">WordPress, Laravel, React</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Also covers</span> <span style="font-weight: 700; color: var(--kilele-navy);">PHP, SEO, Whistle-blowing</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Pricing</span> <span style="font-weight: 700; color: var(--kilele-navy);">From KES 30,000</span></li>
                    </ul>
                    <a href="quote.php" style="margin-top: auto; display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">Get a Quote <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>

            <!-- ============ 3. Hardware Supply & Installation ============ -->
            <div class="product-card" style="background: #fff; border-radius: 18px; overflow: hidden; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; display: flex; flex-direction: column;">
                <div class="product-card__banner product-card__banner--coral" style="padding: 26px; color: white; background: linear-gradient(135deg, var(--kilele-coral), #a94661);">
                    <i class="fas fa-server" style="font-size: 1.8rem; margin-bottom: 10px; display: block;"></i>
                    <h3 style="font-size: 1.15rem; font-weight: 700; margin: 0;">Hardware Supply & Installation</h3>
                </div>
                <div class="product-card__body" style="padding: 22px 24px 26px; flex: 1; display: flex; flex-direction: column;">
                    <p style="font-size: 0.9rem; color: var(--kilele-text-light); line-height: 1.6; margin-bottom: 16px;">
                        Enterprise-grade IT hardware supply and installation — servers, workstations, networking equipment, and storage solutions. End-to-end installation and configuration included.
                    </p>
                    <ul style="list-style: none; padding: 0; margin: 0 0 18px; font-size: 0.82rem; color: var(--kilele-text-dark);">
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Expertise</span> <span style="font-weight: 700; color: var(--kilele-navy);">Dell, HP, Cisco, HPE</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Also covers</span> <span style="font-weight: 700; color: var(--kilele-navy);">Server Racks, Workstations</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Pricing</span> <span style="font-weight: 700; color: var(--kilele-navy);">Free site survey & install</span></li>
                    </ul>
                    <a href="quote.php" style="margin-top: auto; display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">Get a Quote <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>

            <!-- ============ 4. CCTV & Security Systems ============ -->
            <div class="product-card" style="background: #fff; border-radius: 18px; overflow: hidden; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; display: flex; flex-direction: column;">
                <div class="product-card__banner product-card__banner--navy" style="padding: 26px; color: white; background: linear-gradient(135deg, var(--kilele-navy), var(--kilele-dark-navy));">
                    <i class="fas fa-video" style="font-size: 1.8rem; margin-bottom: 10px; display: block;"></i>
                    <h3 style="font-size: 1.15rem; font-weight: 700; margin: 0;">CCTV & Security Systems</h3>
                </div>
                <div class="product-card__body" style="padding: 22px 24px 26px; flex: 1; display: flex; flex-direction: column;">
                    <p style="font-size: 0.9rem; color: var(--kilele-text-light); line-height: 1.6; margin-bottom: 16px;">
                        Design, supply, and installation of CCTV systems, access control, and perimeter security solutions. Analog and IP-based systems with remote monitoring.
                    </p>
                    <ul style="list-style: none; padding: 0; margin: 0 0 18px; font-size: 0.82rem; color: var(--kilele-text-dark);">
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Expertise</span> <span style="font-weight: 700; color: var(--kilele-navy);">IP Cameras, NVRs</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Also covers</span> <span style="font-weight: 700; color: var(--kilele-navy);">Access Control, Biometrics</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Pricing</span> <span style="font-weight: 700; color: var(--kilele-navy);">Free consultation & design</span></li>
                    </ul>
                    <a href="quote.php" style="margin-top: auto; display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">Get a Quote <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>

            <!-- ============ 5. ICT Consulting ============ -->
            <div class="product-card" style="background: #fff; border-radius: 18px; overflow: hidden; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; display: flex; flex-direction: column;">
                <div class="product-card__banner product-card__banner--teal" style="padding: 26px; color: white; background: linear-gradient(135deg, var(--kilele-primary), var(--kilele-primary-dark));">
                    <i class="fas fa-clipboard-list" style="font-size: 1.8rem; margin-bottom: 10px; display: block;"></i>
                    <h3 style="font-size: 1.15rem; font-weight: 700; margin: 0;">ICT Consulting</h3>
                </div>
                <div class="product-card__body" style="padding: 22px 24px 26px; flex: 1; display: flex; flex-direction: column;">
                    <p style="font-size: 0.9rem; color: var(--kilele-text-light); line-height: 1.6; margin-bottom: 16px;">
                        Expert advice on IT strategy, digital transformation, technology roadmaps, and system integration. We help align technology with business goals to maximize ROI.
                    </p>
                    <ul style="list-style: none; padding: 0; margin: 0 0 18px; font-size: 0.82rem; color: var(--kilele-text-dark);">
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Expertise</span> <span style="font-weight: 700; color: var(--kilele-navy);">IT Strategy, Integration</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Also covers</span> <span style="font-weight: 700; color: var(--kilele-navy);">Digital Transformation, Vendor Selection</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Pricing</span> <span style="font-weight: 700; color: var(--kilele-navy);">Consulting packages</span></li>
                    </ul>
                    <a href="quote.php" style="margin-top: auto; display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">Get a Quote <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>

            <!-- ============ 6. Database Management ============ -->
            <div class="product-card" style="background: #fff; border-radius: 18px; overflow: hidden; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; display: flex; flex-direction: column;">
                <div class="product-card__banner product-card__banner--yellow" style="padding: 26px; color: #333; background: linear-gradient(135deg, var(--kilele-yellow), #d99f10);">
                    <i class="fas fa-database" style="font-size: 1.8rem; margin-bottom: 10px; display: block;"></i>
                    <h3 style="font-size: 1.15rem; font-weight: 700; margin: 0;">Database Management</h3>
                </div>
                <div class="product-card__body" style="padding: 22px 24px 26px; flex: 1; display: flex; flex-direction: column;">
                    <p style="font-size: 0.9rem; color: var(--kilele-text-light); line-height: 1.6; margin-bottom: 16px;">
                        Design, deployment, and management of robust database systems — database design, performance tuning, backup & recovery, and migration between platforms.
                    </p>
                    <ul style="list-style: none; padding: 0; margin: 0 0 18px; font-size: 0.82rem; color: var(--kilele-text-dark);">
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Expertise</span> <span style="font-weight: 700; color: var(--kilele-navy);">MySQL, PostgreSQL, MongoDB</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Also covers</span> <span style="font-weight: 700; color: var(--kilele-navy);">Oracle, SQL Server, Cloud DBs</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Pricing</span> <span style="font-weight: 700; color: var(--kilele-navy);">SLA-based support</span></li>
                    </ul>
                    <a href="quote.php" style="margin-top: auto; display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">Get a Quote <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>

            <!-- ============ 7. Security Monitoring ============ -->
            <div class="product-card" style="background: #fff; border-radius: 18px; overflow: hidden; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; display: flex; flex-direction: column;">
                <div class="product-card__banner product-card__banner--coral" style="padding: 26px; color: white; background: linear-gradient(135deg, var(--kilele-coral), #a94661);">
                    <i class="fas fa-eye" style="font-size: 1.8rem; margin-bottom: 10px; display: block;"></i>
                    <h3 style="font-size: 1.15rem; font-weight: 700; margin: 0;">Security Monitoring</h3>
                </div>
                <div class="product-card__body" style="padding: 22px 24px 26px; flex: 1; display: flex; flex-direction: column;">
                    <p style="font-size: 0.9rem; color: var(--kilele-text-light); line-height: 1.6; margin-bottom: 16px;">
                        24/7 security monitoring for IT infrastructure, websites, and networks. Real-time threat detection, vulnerability scanning, and incident response.
                    </p>
                    <ul style="list-style: none; padding: 0; margin: 0 0 18px; font-size: 0.82rem; color: var(--kilele-text-dark);">
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Expertise</span> <span style="font-weight: 700; color: var(--kilele-navy);">SIEM, Vulnerability Assessment</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Also covers</span> <span style="font-weight: 700; color: var(--kilele-navy);">Threat Hunting, Incident Response</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Pricing</span> <span style="font-weight: 700; color: var(--kilele-navy);">24/7 monitoring & response</span></li>
                    </ul>
                    <a href="quote.php" style="margin-top: auto; display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">Get a Quote <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>

            <!-- ============ 8. Firewall Solutions ============ -->
            <div class="product-card" style="background: #fff; border-radius: 18px; overflow: hidden; box-shadow: 0 5px 20px rgba(0,0,0,0.06); transition: all 0.3s ease; display: flex; flex-direction: column;">
                <div class="product-card__banner product-card__banner--navy" style="padding: 26px; color: white; background: linear-gradient(135deg, var(--kilele-navy), var(--kilele-dark-navy));">
                    <i class="fas fa-fire" style="font-size: 1.8rem; margin-bottom: 10px; display: block;"></i>
                    <h3 style="font-size: 1.15rem; font-weight: 700; margin: 0;">Firewall Solutions</h3>
                </div>
                <div class="product-card__body" style="padding: 22px 24px 26px; flex: 1; display: flex; flex-direction: column;">
                    <p style="font-size: 0.9rem; color: var(--kilele-text-light); line-height: 1.6; margin-bottom: 16px;">
                        Design, implementation, and management of enterprise-grade firewall solutions to protect your network from cyber threats.
                    </p>
                    <ul style="list-style: none; padding: 0; margin: 0 0 18px; font-size: 0.82rem; color: var(--kilele-text-dark);">
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Expertise</span> <span style="font-weight: 700; color: var(--kilele-navy);">Fortinet, Cisco, Palo Alto</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Also covers</span> <span style="font-weight: 700; color: var(--kilele-navy);">Sophos, SonicWall</span></li>
                        <li style="display: flex; justify-content: space-between; padding: 6px 0;"><span>Pricing</span> <span style="font-weight: 700; color: var(--kilele-navy);">Free network security audit</span></li>
                    </ul>
                    <a href="quote.php" style="margin-top: auto; display: inline-flex; align-items: center; gap: 6px; font-size: 0.9rem; font-weight: 700; color: var(--kilele-primary); text-decoration: none;">Get a Quote <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>

        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>