<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit; 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Kilele Tech</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { 
            background: linear-gradient(145deg, #f0f5f7 0%, #e6f0ef 100%);
            min-height: 100vh;
            font-family: 'Poppins', sans-serif; 
        }
        .dashboard-card { 
            background: #ffffff; 
            border-radius: 20px; 
            padding: 40px 30px; 
            box-shadow: 0 8px 24px rgba(15, 30, 51, 0.08); 
            transition: all 0.3s ease; 
            height: 100%;
            border: 1px solid rgba(255,255,255,0.5);
            cursor: pointer;
        }
        .dashboard-card:hover { 
            transform: translateY(-6px); 
            box-shadow: 0 15px 35px rgba(15, 30, 51, 0.12); 
        }
        .brand-color { color: #29A08E; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Welcome, <span class="brand-color"><?php echo htmlspecialchars($_SESSION['admin_user']); ?></span>!</h2>
            <p class="text-secondary">Manage all your KileleTech data from one central hub.</p>
        </div>
        
        <div class="row g-4 justify-content-center">
            
            <!-- Contact Messages -->
            <div class="col-md-4">
                <a href="messages.php" class="text-decoration-none text-dark" style="display: block; height: 100%;">
                    <div class="dashboard-card text-center">
                        <i class="fas fa-envelope fa-4x brand-color mb-4"></i>
                        <h5 class="fw-bold">Contact Messages</h5>
                        <small class="text-muted">View user inquiries</small>
                    </div>
                </a>
            </div>

            <!-- Newsletter Subscribers -->
            <div class="col-md-4">
                <a href="subscribers.php" class="text-decoration-none text-dark" style="display: block; height: 100%;">
                    <div class="dashboard-card text-center">
                        <i class="fas fa-users fa-4x brand-color mb-4"></i>
                        <h5 class="fw-bold">Newsletter Subscribers</h5>
                        <small class="text-muted">View mailing list</small>
                    </div>
                </a>
            </div>

            <!-- Quote Requests (UPDATED LINK) -->
            <div class="col-md-4">
                <a href="view_quotes.php" class="text-decoration-none text-dark" style="display: block; height: 100%;">
                    <div class="dashboard-card text-center">
                        <i class="fas fa-file-invoice fa-4x brand-color mb-4"></i>
                        <h5 class="fw-bold">Quote Requests</h5>
                        <small class="text-muted">Review client quotes</small>
                    </div>
                </a>
            </div>

            <!-- Manage Admins -->
            <div class="col-md-4 offset-md-2">
                <a href="users.php" class="text-decoration-none text-dark" style="display: block; height: 100%;">
                    <div class="dashboard-card text-center">
                        <i class="fas fa-user-shield fa-4x brand-color mb-4"></i>
                        <h5 class="fw-bold">Manage Admins</h5>
                        <small class="text-muted">Add / remove admin users</small>
                    </div>
                </a>
            </div>

            <!-- Logout -->
            <div class="col-md-4">
                <a href="logout.php" class="text-decoration-none text-danger" style="display: block; height: 100%;">
                    <div class="dashboard-card text-center">
                        <i class="fas fa-sign-out-alt fa-4x text-danger mb-4"></i>
                        <h5 class="fw-bold text-danger">Logout</h5>
                        <small class="text-muted">Secure exit</small>
                    </div>
                </a>
            </div>

        </div>
    </div>
</body>
</html>