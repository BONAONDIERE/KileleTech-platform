<?php
session_start();
require_once '../includes/db.php';

// Restrict access - kick out if not logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Fetch subscribers from database
$subscribers = [];
try {
    $stmt = $pdo->query("SELECT * FROM newsletter_subscribers ORDER BY subscribed_at DESC");
    $subscribers = $stmt->fetchAll();
} catch (PDOException $e) {
    // If the table doesn't exist, just leave it empty
}

// Helper function for formatting the status safely
function getStatusBadge($status = null) {
    if (!$status) return '<span class="badge bg-success">Active</span>';
    switch ($status) {
        case 'active': return '<span class="badge bg-success">Active</span>';
        case 'unsubscribed': return '<span class="badge bg-danger">Unsubscribed</span>';
        default: return '<span class="badge bg-secondary">Unknown</span>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscribers – KileleTech Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8fafb; font-family: 'Poppins', sans-serif; }
        .sidebar { background: #0f1e33; min-height: 100vh; padding: 20px 0; }
        .sidebar .logo h4 { color: #29A08E; font-weight: 700; text-align: center; padding: 10px 0; }
        .sidebar .nav-link { color: rgba(255,255,255,0.7); padding: 12px 24px; border-radius: 8px; margin: 4px 12px; transition: 0.3s; }
        .sidebar .nav-link:hover { background: rgba(255,255,255,0.05); color: #fff; }
        .sidebar .nav-link.active { background: #29A08E; color: white; }
        .main-content { padding: 24px; }
        .table-card { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 2px 12px rgba(0,0,0,0.05); }
        .top-bar { background: #fff; padding: 12px 24px; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.05); margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 col-lg-2 sidebar">
                <div class="logo"><h4>KileleTech</h4></div>
                <nav class="nav flex-column mt-3">
                    <a href="dashboard.php" class="nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
                    <a href="messages.php" class="nav-link"><i class="fas fa-envelope"></i> Messages</a>
                    <a href="subscribers.php" class="nav-link active"><i class="fas fa-users"></i> Subscribers</a>
                    <a href="logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 col-lg-10 main-content">
                <div class="top-bar">
                    <div>
                        <h5 class="mb-0">Newsletter Subscribers</h5>
                        <small class="text-muted">Total: <?php echo count($subscribers); ?> subscribers</small>
                    </div>
                    <!-- NEW EXPORT BUTTON -->
                    <div>
                        <a href="export_subscribers.php" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-file-export me-1"></i> Export CSV
                        </a>
                    </div>
                </div>

                <div class="table-card">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Subscribed Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($subscribers) > 0): ?>
                                    <?php foreach ($subscribers as $sub): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($sub['id']); ?></td>
                                            <td><?php echo htmlspecialchars($sub['email']); ?></td>
                                            <td><?php echo getStatusBadge($sub['status'] ?? null); ?></td>
                                            <td><?php echo date('M j, g:i A', strtotime($sub['subscribed_at'])); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-3">No subscribers yet.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>