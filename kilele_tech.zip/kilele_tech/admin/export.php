<?php
// ============================================================
// EXPORT DATA TO CSV
// ============================================================

require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

requireLogin();

$type = $_GET['type'] ?? 'contact';

$tableMap = [
    'contact' => 'contact_submissions',
    'quote' => 'quote_requests',
    'join' => 'join_requests'
];

$table = $tableMap[$type] ?? 'contact_submissions';

// Get all data
$data = getSubmissions($db, $table, 10000, 0);

if (empty($data)) {
    header('Location: messages.php?type=' . $type);
    exit;
}

// Set headers for CSV download
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $type . '_submissions_' . date('Y-m-d') . '.csv"');

$output = fopen('php://output', 'w');

// Write headers
if ($data) {
    fputcsv($output, array_keys($data[0]));
}

// Write data
foreach ($data as $row) {
    fputcsv($output, $row);
}

fclose($output);
exit;