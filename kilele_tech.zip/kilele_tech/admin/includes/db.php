<?php
/**
 * Shared database connection.
 * Included by root pages and admin files.
 */

$DB_HOST = '127.0.0.1';
$DB_NAME = 'kilele_tech';
$DB_USER = 'root';
$DB_PASS = '';

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    die('Database connection failed. Check that MySQL is running in XAMPP and that the "kilele_tech" database exists. Error: ' . $e->getMessage());
}
?>